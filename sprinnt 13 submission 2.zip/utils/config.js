const JWT_SECRET = "pasword";
module.exports = { JWT_SECRET };
